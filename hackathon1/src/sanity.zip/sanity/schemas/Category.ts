export const category = {
  name: "category",
  type: "document",
  title: "Course Category",
  fields: [
    {
      name: "title",
      type: "string",
      title: "Course Category",
    },
  ],
};
