export const brand = {
  name: "brand",
  type: "document",
  title: "Product Brand",
  fields: [
    {
      name: "title",
      type: "string",
      title: "Product Brand",
    },
  ],
};
